export interface ResponseApiType {
    success: boolean,
    message: string,
    data?: Object,
    errors?: Object
}