-- DropForeignKey
ALTER TABLE "PlagiarismResult" DROP CONSTRAINT "PlagiarismResult_doc1Id_fkey";

-- DropForeignKey
ALTER TABLE "PlagiarismResult" DROP CONSTRAINT "PlagiarismResult_doc2Id_fkey";

-- AddForeignKey
ALTER TABLE "PlagiarismResult" ADD CONSTRAINT "PlagiarismResult_doc1Id_fkey" FOREIGN KEY ("doc1Id") REFERENCES "Document"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PlagiarismResult" ADD CONSTRAINT "PlagiarismResult_doc2Id_fkey" FOREIGN KEY ("doc2Id") REFERENCES "Document"("id") ON DELETE CASCADE ON UPDATE CASCADE;
