/*
  Warnings:

  - The values [COSINE_SIMILARITY,JACCARD] on the enum `Algorithm` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "Algorithm_new" AS ENUM ('RABIN_KARP');
ALTER TABLE "plagiarism_results" ALTER COLUMN "algorithm" DROP DEFAULT;
ALTER TABLE "plagiarism_results" ALTER COLUMN "algorithm" TYPE "Algorithm_new" USING ("algorithm"::text::"Algorithm_new");
ALTER TYPE "Algorithm" RENAME TO "Algorithm_old";
ALTER TYPE "Algorithm_new" RENAME TO "Algorithm";
DROP TYPE "Algorithm_old";
ALTER TABLE "plagiarism_results" ALTER COLUMN "algorithm" SET DEFAULT 'RABIN_KARP';
COMMIT;
